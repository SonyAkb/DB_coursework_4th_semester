-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: coursework_db_akbasheva
-- ------------------------------------------------------
-- Server version	8.0.39

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `product`
--

DROP TABLE IF EXISTS `product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product` (
  `ProductID` int NOT NULL AUTO_INCREMENT,
  `CategoryID` int NOT NULL,
  `ProductName` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `Description` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `Price` decimal(15,2) NOT NULL,
  `MinimumStockLevel` int NOT NULL DEFAULT '5',
  `MaximumStockLevel` int DEFAULT NULL,
  `IsActive` bit(1) NOT NULL DEFAULT b'1',
  PRIMARY KEY (`ProductID`),
  KEY `CategoryID` (`CategoryID`),
  KEY `idx_product_price` (`Price`),
  KEY `idx_product_min_stock` (`MinimumStockLevel`),
  CONSTRAINT `product_ibfk_1` FOREIGN KEY (`CategoryID`) REFERENCES `productcategory` (`CategoryID`),
  CONSTRAINT `chk_min_stock` CHECK ((`MinimumStockLevel` >= 0)),
  CONSTRAINT `chk_price` CHECK ((`Price` > 0))
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product`
--

LOCK TABLES `product` WRITE;
/*!40000 ALTER TABLE `product` DISABLE KEYS */;
INSERT INTO `product` VALUES (1,1,'Беговая дорожка ProForm 1000','Мощность 3.0 л.с., max скорость 20 км/ч, складная',899.99,5,20,_binary ''),(2,1,'Эллиптический тренажер EvoFit CX30','Магнитная система нагрузки, 16 уровней',1200.00,3,15,_binary ''),(3,1,'Силовая станция BodyCraft Xpress','15 упражнений, вес стека 90 кг',2500.00,2,10,_binary ''),(4,2,'Гантели наборные 20 кг','Резиновое покрытие, блины по 2.5 кг',89.99,10,50,_binary ''),(5,2,'Йога-мат Premium 6мм','Экологичный материал, размер 183x61 см',24.50,20,100,_binary ''),(6,2,'Эспандер ленточный (5 шт)','Набор резиновых лент разной жесткости',35.00,15,80,_binary ''),(7,3,'Мяч футбольный Adidas Finale','Размер 5, официальный мяч UEFA',129.99,8,40,_binary ''),(8,3,'Сетка волейбольная Wilson','Официальная высота 2.43м, полипропилен',79.95,5,25,_binary ''),(9,3,'Щит баскетбольный Spalding','Размер 180x105 см, небьющийся',450.00,3,12,_binary ''),(10,4,'Лыжи горные Atomic Redster','Ростовка 170см, радиус 14м',700.00,2,8,_binary ''),(11,4,'Сноуборд Burton Custom','Доска 158см, крепления в комплекте',850.00,2,6,_binary ''),(12,4,'Коньки хоккейные Bauer Vapor','Размер 42, жесткий ботинок',300.00,4,15,_binary ''),(13,5,'Палатка 4-местная Coleman','Водонепроницаемость 5000мм, вес 5.8кг',350.00,3,12,_binary ''),(14,5,'Рюкзак туристический Osprey 65л','Анатомическая спинка, дождевик в комплекте',280.00,5,20,_binary ''),(15,5,'Спальник синтетический -5°C','Комфортная температура до -5°C',120.00,7,30,_binary ''),(16,6,'Горный велосипед Trek Marlin 5','Рама 19\", 21 скорость, дисковые тормоза',950.00,2,5,_binary ''),(17,6,'Шлем велосипедный Giro','Вентиляция, регулировка размера',89.95,6,25,_binary ''),(18,6,'Фонарь велосипедный Sigma 200','200 люмен, USB-зарядка',45.00,10,40,_binary ''),(19,7,'Очки для плавания Speedo','УФ-защита, антизапотевающее покрытие',25.99,15,60,_binary ''),(20,7,'Шапочка силиконовая Arena','Гладкий силикон, 3 размера',12.50,20,80,_binary ''),(21,7,'Доска для плавания TYR','Пенопласт высокой плотности',18.00,12,50,_binary ''),(22,8,'Кроссовки беговые Nike Air Zoom','Амортизация, размеры 38-46',130.00,8,35,_binary ''),(23,8,'Гидратор CamelBak 1.5л','Рюкзак с системой гидратации',75.00,5,20,_binary ''),(24,8,'Пульсометр Polar H10','Точность 99%, водонепроницаемый',90.00,4,15,_binary '');
/*!40000 ALTER TABLE `product` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-07-08 17:23:11
