-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: coursework_db_akbasheva
-- ------------------------------------------------------
-- Server version	8.0.39

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `employee`
--

DROP TABLE IF EXISTS `employee`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `employee` (
  `EmployeeID` int NOT NULL AUTO_INCREMENT,
  `DepartmentID` int NOT NULL,
  `JobTitleID` int NOT NULL,
  `LastName` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `FirstName` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `Patronymic` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `HireDate` date NOT NULL,
  `Salary` decimal(15,2) NOT NULL,
  `CommissionRate` decimal(5,2) DEFAULT NULL,
  `Description` longtext,
  PRIMARY KEY (`EmployeeID`),
  KEY `DepartmentID` (`DepartmentID`),
  KEY `JobTitleID` (`JobTitleID`),
  CONSTRAINT `employee_ibfk_1` FOREIGN KEY (`DepartmentID`) REFERENCES `department` (`DepartmentID`),
  CONSTRAINT `employee_ibfk_2` FOREIGN KEY (`JobTitleID`) REFERENCES `jobtitle` (`JobTitleID`),
  CONSTRAINT `chk_commission` CHECK (((`CommissionRate` between 0 and 100) or (`CommissionRate` is null))),
  CONSTRAINT `chk_salary` CHECK ((`Salary` > 0))
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee`
--

LOCK TABLES `employee` WRITE;
/*!40000 ALTER TABLE `employee` DISABLE KEYS */;
INSERT INTO `employee` VALUES (11,1,1,'Иванова','Анна','Сергеевна','2020-05-15',85000.00,5.00,'Старший менеджер по работе с ключевыми клиентами'),(12,1,1,'Петров','Дмитрий','Игоревич','2021-02-20',75000.00,3.50,NULL),(13,2,2,'Смирнова','Елена','Викторовна','2019-11-10',90000.00,NULL,'Главный бухгалтер'),(14,2,2,'Козлов','Артём','Олегович','2022-01-15',60000.00,NULL,NULL),(15,3,3,'Фёдорова','Ольга','Александровна','2020-08-22',80000.00,NULL,'Анализ кредитоспособности клиентов'),(16,6,6,'Соколов','Михаил','Денисович','2021-04-05',65000.00,7.00,'Северная Америка'),(17,6,6,'Морозова','Алиса','Романовна','2022-03-12',62000.00,6.50,'Европа'),(18,5,5,'Лебедев','Иван','Алексеевич','2021-07-30',70000.00,NULL,'Координация отгрузок'),(19,4,7,'Новиков','Сергей','Валерьевич','2018-09-17',120000.00,NULL,'Начальник отдела маркетинга'),(20,1,7,'Захарова','Виктория','Андреевна','2019-03-25',110000.00,NULL,'Руководитель отдела продаж');
/*!40000 ALTER TABLE `employee` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-07-08 17:23:08
