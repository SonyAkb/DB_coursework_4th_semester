-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: coursework_db_akbasheva
-- ------------------------------------------------------
-- Server version	8.0.39

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `legaldetails`
--

DROP TABLE IF EXISTS `legaldetails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `legaldetails` (
  `LegalID` int NOT NULL AUTO_INCREMENT,
  `CustomerID` int NOT NULL,
  `TaxID` varchar(50) NOT NULL,
  `ReasonCode` varchar(50) DEFAULT NULL,
  `RegistrationNumber` varchar(50) NOT NULL,
  `LegalAddress` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `CEOFullName` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `CEOPosition` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  PRIMARY KEY (`LegalID`),
  KEY `CustomerID` (`CustomerID`),
  CONSTRAINT `legaldetails_ibfk_1` FOREIGN KEY (`CustomerID`) REFERENCES `customer` (`CustomerID`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `legaldetails`
--

LOCK TABLES `legaldetails` WRITE;
/*!40000 ALTER TABLE `legaldetails` DISABLE KEYS */;
INSERT INTO `legaldetails` VALUES (1,1,'94-1234567',NULL,'C123456789','300 Jefferson St, San Francisco, CA 94133, USA','John McAllister','CEO'),(2,2,'91-9876543',NULL,'C987654321','1501 4th Ave, Seattle, WA 98101, USA','Sarah Peterson','President'),(3,3,'45-3456789',NULL,'C345678901','5505 Peachtree Rd, Atlanta, GA 30341, USA','Richard Thompson','Chief Executive Officer'),(4,4,'12-5678912',NULL,'C567891234','1600 Maple St, Boulder, CO 80302, USA','Robert Langley','Founder & CEO'),(5,5,'123456789RT0001','987654321','BC1234567','2000 Fitness Way, Toronto, ON M5V 3L5, Canada','Michelle Leblanc','Directrice Générale'),(6,6,'987654321QC001','123456789','QC9876543','123 Playground Ave, Montreal, QC H3B 2Y5, Canada','Jacques Tremblay','Président-Directeur Général'),(7,7,'DE123456789',NULL,'HRB 123456','Friedrichstrasse 68, 10117 Berlin, Germany','Klaus Schmidt','Geschäftsführer'),(8,8,'CHE-123.456.789 MWST',NULL,'CH-123.4.567','Rue du Mont-Blanc 15, 1201 Genève, Switzerland','Pierre Dubois','Directeur Général'),(9,9,'GB123456789',NULL,'07896543','Oxford Street 250, London W1C 1DJ, UK','Elizabeth Windsor','Managing Director'),(10,10,'123-45-67890',NULL,'0100-01-123456','1-2-3 Shibuya, Tokyo 150-0043, Japan','Takeshi Yamamoto','代表取締役社長'),(11,11,'913101157845612345',NULL,'310115000123456','Nanjing Road 123, Shanghai 200001, China','Zhang Wei','董事长'),(12,12,'123-45-67890',NULL,'110111-1234567','Gangnam-daero 132, Seoul 06164, South Korea','Lee Ji-hoon','대표이사'),(13,13,'12.345.678/0001-90',NULL,'12345678000190','Copacabana Beach 200, Rio de Janeiro 22070-010, Brazil','Carlos Oliveira','Diretor Presidente'),(14,14,'123456789123456',NULL,'CN-1234567','Sheikh Zayed Rd 1000, Dubai, UAE','Ahmed Al-Maktoum','Managing Director'),(15,15,'1234567890',NULL,'2010/123456/07','Table Mountain Rd, Cape Town 8001, South Africa','Jacob Zuma','Chief Executive Officer');
/*!40000 ALTER TABLE `legaldetails` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-07-08 17:23:10
