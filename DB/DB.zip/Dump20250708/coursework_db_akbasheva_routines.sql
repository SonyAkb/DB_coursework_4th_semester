-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: coursework_db_akbasheva
-- ------------------------------------------------------
-- Server version	8.0.39

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Temporary view structure for view `v_payment_method_stats`
--

DROP TABLE IF EXISTS `v_payment_method_stats`;
/*!50001 DROP VIEW IF EXISTS `v_payment_method_stats`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_payment_method_stats` AS SELECT 
 1 AS `PaymentMethodID`,
 1 AS `PaymentMethodName`,
 1 AS `PaymentCount`,
 1 AS `TotalAmount`,
 1 AS `Percentage`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_customer_debtors`
--

DROP TABLE IF EXISTS `v_customer_debtors`;
/*!50001 DROP VIEW IF EXISTS `v_customer_debtors`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_customer_debtors` AS SELECT 
 1 AS `CustomerID`,
 1 AS `CustomerName`,
 1 AS `InvoiceID`,
 1 AS `InvoiceAmount`,
 1 AS `DueDate`,
 1 AS `DaysOverdue`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_top_products`
--

DROP TABLE IF EXISTS `v_top_products`;
/*!50001 DROP VIEW IF EXISTS `v_top_products`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_top_products` AS SELECT 
 1 AS `ProductID`,
 1 AS `ProductName`,
 1 AS `CategoryName`,
 1 AS `OrderCount`,
 1 AS `TotalQuantity`,
 1 AS `TotalRevenue`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_sales_performance`
--

DROP TABLE IF EXISTS `v_sales_performance`;
/*!50001 DROP VIEW IF EXISTS `v_sales_performance`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_sales_performance` AS SELECT 
 1 AS `EmployeeID`,
 1 AS `EmployeeName`,
 1 AS `DepartmentName`,
 1 AS `TotalOrders`,
 1 AS `TotalSales`,
 1 AS `EstimatedCommission`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_related_products`
--

DROP TABLE IF EXISTS `v_related_products`;
/*!50001 DROP VIEW IF EXISTS `v_related_products`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_related_products` AS SELECT 
 1 AS `MainProductID`,
 1 AS `MainProductName`,
 1 AS `RelatedProductID`,
 1 AS `RelatedProductName`,
 1 AS `TimesOrderedTogether`,
 1 AS `AssociationPercentage`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_top_customers_last_quarter`
--

DROP TABLE IF EXISTS `v_top_customers_last_quarter`;
/*!50001 DROP VIEW IF EXISTS `v_top_customers_last_quarter`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_top_customers_last_quarter` AS SELECT 
 1 AS `CustomerID`,
 1 AS `CustomerName`,
 1 AS `RegionName`,
 1 AS `OrderCount`,
 1 AS `TotalSpent`,
 1 AS `OrderDate`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_department_staff`
--

DROP TABLE IF EXISTS `v_department_staff`;
/*!50001 DROP VIEW IF EXISTS `v_department_staff`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_department_staff` AS SELECT 
 1 AS `DepartmentID`,
 1 AS `DepartmentName`,
 1 AS `EmployeeCount`,
 1 AS `AverageSalary`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_region_warehouse_stock`
--

DROP TABLE IF EXISTS `v_region_warehouse_stock`;
/*!50001 DROP VIEW IF EXISTS `v_region_warehouse_stock`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_region_warehouse_stock` AS SELECT 
 1 AS `RegionID`,
 1 AS `RegionName`,
 1 AS `ProductID`,
 1 AS `ProductName`,
 1 AS `TotalInStock`,
 1 AS `WarehouseID`,
 1 AS `WarehouseAddress`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_low_stock_products`
--

DROP TABLE IF EXISTS `v_low_stock_products`;
/*!50001 DROP VIEW IF EXISTS `v_low_stock_products`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_low_stock_products` AS SELECT 
 1 AS `ProductID`,
 1 AS `ProductName`,
 1 AS `WarehouseID`,
 1 AS `WarehouseLocation`,
 1 AS `QuantityInStock`,
 1 AS `MinimumStockLevel`,
 1 AS `Deficit`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_avg_order_by_region`
--

DROP TABLE IF EXISTS `v_avg_order_by_region`;
/*!50001 DROP VIEW IF EXISTS `v_avg_order_by_region`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_avg_order_by_region` AS SELECT 
 1 AS `RegionID`,
 1 AS `RegionName`,
 1 AS `TotalOrders`,
 1 AS `AverageOrderAmount`,
 1 AS `TotalSales`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_orders_with_status`
--

DROP TABLE IF EXISTS `v_orders_with_status`;
/*!50001 DROP VIEW IF EXISTS `v_orders_with_status`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_orders_with_status` AS SELECT 
 1 AS `OrderID`,
 1 AS `CustomerName`,
 1 AS `StatusName`,
 1 AS `OrderDate`,
 1 AS `TotalAmount`,
 1 AS `ShipmentDate`,
 1 AS `EstimatedArrivalDate`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_customer_with_region`
--

DROP TABLE IF EXISTS `v_customer_with_region`;
/*!50001 DROP VIEW IF EXISTS `v_customer_with_region`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_customer_with_region` AS SELECT 
 1 AS `CustomerID`,
 1 AS `CustomerName`,
 1 AS `Country`,
 1 AS `Region`,
 1 AS `CreditLimit`*/;
SET character_set_client = @saved_cs_client;

--
-- Final view structure for view `v_payment_method_stats`
--

/*!50001 DROP VIEW IF EXISTS `v_payment_method_stats`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_payment_method_stats` AS select `pm`.`PaymentMethodID` AS `PaymentMethodID`,`pm`.`PaymentMethodName` AS `PaymentMethodName`,count(`p`.`PaymentID`) AS `PaymentCount`,sum(`p`.`Amount`) AS `TotalAmount`,round(((count(`p`.`PaymentID`) * 100.0) / (select count(0) from `payment`)),2) AS `Percentage` from (`paymentmethod` `pm` left join `payment` `p` on((`pm`.`PaymentMethodID` = `p`.`PaymentMethodID`))) group by `pm`.`PaymentMethodID`,`pm`.`PaymentMethodName` order by `PaymentCount` desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_customer_debtors`
--

/*!50001 DROP VIEW IF EXISTS `v_customer_debtors`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_customer_debtors` AS select `c`.`CustomerID` AS `CustomerID`,`c`.`CustomerName` AS `CustomerName`,`i`.`InvoiceID` AS `InvoiceID`,`i`.`InvoiceAmount` AS `InvoiceAmount`,`i`.`DueDate` AS `DueDate`,(to_days(curdate()) - to_days(`i`.`DueDate`)) AS `DaysOverdue` from (((`customer` `c` join `ordering` `o` on((`c`.`CustomerID` = `o`.`CustomerID`))) join `invoice` `i` on((`o`.`OrderID` = `i`.`OrderID`))) left join `payment` `p` on((`i`.`OrderID` = `p`.`OrderID`))) where ((`i`.`InvoiceStatusID` = (select `paymentstatus`.`StatusID` from `paymentstatus` where (`paymentstatus`.`StatusName` like '%Ожидает оплаты%'))) and (`i`.`DueDate` < curdate())) group by `i`.`InvoiceID` having (sum(ifnull(`p`.`Amount`,0)) < `i`.`InvoiceAmount`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_top_products`
--

/*!50001 DROP VIEW IF EXISTS `v_top_products`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_top_products` AS select `p`.`ProductID` AS `ProductID`,`p`.`ProductName` AS `ProductName`,`pc`.`CategoryName` AS `CategoryName`,count(`oi`.`OrderID`) AS `OrderCount`,sum(`oi`.`Quantity`) AS `TotalQuantity`,sum((`oi`.`Quantity` * `oi`.`UnitPrice`)) AS `TotalRevenue` from (((`product` `p` join `productcategory` `pc` on((`p`.`CategoryID` = `pc`.`CategoryID`))) join `orderitem` `oi` on((`p`.`ProductID` = `oi`.`ProductID`))) join `ordering` `o` on((`oi`.`OrderID` = `o`.`OrderID`))) where (`p`.`IsActive` = 1) group by `p`.`ProductID`,`p`.`ProductName`,`pc`.`CategoryName` order by `OrderCount` desc limit 10 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_sales_performance`
--

/*!50001 DROP VIEW IF EXISTS `v_sales_performance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_sales_performance` AS select `e`.`EmployeeID` AS `EmployeeID`,concat(`e`.`LastName`,' ',`e`.`FirstName`) AS `EmployeeName`,`d`.`DepartmentName` AS `DepartmentName`,count(`o`.`OrderID`) AS `TotalOrders`,sum(`o`.`TotalAmount`) AS `TotalSales`,round(((sum(`o`.`TotalAmount`) * `e`.`CommissionRate`) / 100),2) AS `EstimatedCommission` from ((`employee` `e` join `department` `d` on((`e`.`DepartmentID` = `d`.`DepartmentID`))) join `ordering` `o` on((`e`.`EmployeeID` = `o`.`EmployeeID`))) where (`e`.`CommissionRate` is not null) group by `e`.`EmployeeID`,`e`.`LastName`,`e`.`FirstName`,`d`.`DepartmentName`,`e`.`CommissionRate` order by `TotalSales` desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_related_products`
--

/*!50001 DROP VIEW IF EXISTS `v_related_products`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_related_products` AS select `main`.`ProductID` AS `MainProductID`,`main`.`ProductName` AS `MainProductName`,`related`.`ProductID` AS `RelatedProductID`,`related`.`ProductName` AS `RelatedProductName`,count(0) AS `TimesOrderedTogether`,round(((count(0) * 100.0) / (select count(0) from `orderitem` where (`orderitem`.`ProductID` = `main`.`ProductID`))),2) AS `AssociationPercentage` from (((`orderitem` `oi1` join `orderitem` `oi2` on(((`oi1`.`OrderID` = `oi2`.`OrderID`) and (`oi1`.`ProductID` <> `oi2`.`ProductID`)))) join `product` `main` on((`oi1`.`ProductID` = `main`.`ProductID`))) join `product` `related` on((`oi2`.`ProductID` = `related`.`ProductID`))) group by `main`.`ProductID`,`main`.`ProductName`,`related`.`ProductID`,`related`.`ProductName` order by `TimesOrderedTogether` desc limit 20 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_top_customers_last_quarter`
--

/*!50001 DROP VIEW IF EXISTS `v_top_customers_last_quarter`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_top_customers_last_quarter` AS select `c`.`CustomerID` AS `CustomerID`,`c`.`CustomerName` AS `CustomerName`,`r`.`RegionName` AS `RegionName`,count(`o`.`OrderID`) AS `OrderCount`,sum(`o`.`TotalAmount`) AS `TotalSpent`,`o`.`OrderDate` AS `OrderDate` from ((`customer` `c` join `region` `r` on((`c`.`RegionID` = `r`.`RegionID`))) join `ordering` `o` on((`c`.`CustomerID` = `o`.`CustomerID`))) group by `c`.`CustomerID`,`c`.`CustomerName`,`r`.`RegionName`,`o`.`OrderDate` order by `OrderCount` desc limit 10 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_department_staff`
--

/*!50001 DROP VIEW IF EXISTS `v_department_staff`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_department_staff` AS select `d`.`DepartmentID` AS `DepartmentID`,`d`.`DepartmentName` AS `DepartmentName`,count(`e`.`EmployeeID`) AS `EmployeeCount`,round(avg(`e`.`Salary`),2) AS `AverageSalary` from (`department` `d` left join `employee` `e` on((`d`.`DepartmentID` = `e`.`DepartmentID`))) group by `d`.`DepartmentID`,`d`.`DepartmentName` order by `EmployeeCount` desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_region_warehouse_stock`
--

/*!50001 DROP VIEW IF EXISTS `v_region_warehouse_stock`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_region_warehouse_stock` AS select `r`.`RegionID` AS `RegionID`,`r`.`RegionName` AS `RegionName`,`p`.`ProductID` AS `ProductID`,`p`.`ProductName` AS `ProductName`,sum(`i`.`QuantityInStock`) AS `TotalInStock`,`w`.`WarehouseID` AS `WarehouseID`,`w`.`Address` AS `WarehouseAddress` from (((`region` `r` join `warehouse` `w` on((`r`.`RegionID` = `w`.`RegionID`))) join `inventory` `i` on((`w`.`WarehouseID` = `i`.`WarehouseID`))) join `product` `p` on((`i`.`ProductID` = `p`.`ProductID`))) group by `r`.`RegionID`,`r`.`RegionName`,`p`.`ProductID`,`p`.`ProductName`,`w`.`WarehouseID`,`w`.`Address` order by `r`.`RegionName`,`p`.`ProductName` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_low_stock_products`
--

/*!50001 DROP VIEW IF EXISTS `v_low_stock_products`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_low_stock_products` AS select `p`.`ProductID` AS `ProductID`,`p`.`ProductName` AS `ProductName`,`i`.`WarehouseID` AS `WarehouseID`,`w`.`Address` AS `WarehouseLocation`,`i`.`QuantityInStock` AS `QuantityInStock`,`p`.`MinimumStockLevel` AS `MinimumStockLevel`,(`p`.`MinimumStockLevel` - `i`.`QuantityInStock`) AS `Deficit` from ((`product` `p` join `inventory` `i` on((`p`.`ProductID` = `i`.`ProductID`))) join `warehouse` `w` on((`i`.`WarehouseID` = `w`.`WarehouseID`))) where ((`i`.`QuantityInStock` < `p`.`MinimumStockLevel`) and (`p`.`IsActive` = 1)) order by (`p`.`MinimumStockLevel` - `i`.`QuantityInStock`) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_avg_order_by_region`
--

/*!50001 DROP VIEW IF EXISTS `v_avg_order_by_region`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_avg_order_by_region` AS select `r`.`RegionID` AS `RegionID`,`r`.`RegionName` AS `RegionName`,count(`o`.`OrderID`) AS `TotalOrders`,avg(`o`.`TotalAmount`) AS `AverageOrderAmount`,sum(`o`.`TotalAmount`) AS `TotalSales` from ((`region` `r` join `customer` `c` on((`r`.`RegionID` = `c`.`RegionID`))) join `ordering` `o` on((`c`.`CustomerID` = `o`.`CustomerID`))) group by `r`.`RegionID`,`r`.`RegionName` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_orders_with_status`
--

/*!50001 DROP VIEW IF EXISTS `v_orders_with_status`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_orders_with_status` AS select `o`.`OrderID` AS `OrderID`,`c`.`CustomerName` AS `CustomerName`,`os`.`StatusName` AS `StatusName`,`o`.`OrderDate` AS `OrderDate`,`o`.`TotalAmount` AS `TotalAmount`,`s`.`ShipmentDate` AS `ShipmentDate`,`s`.`EstimatedArrivalDate` AS `EstimatedArrivalDate` from (((`ordering` `o` join `customer` `c` on((`o`.`CustomerID` = `c`.`CustomerID`))) join `orderstatus` `os` on((`o`.`StatusID` = `os`.`StatusID`))) left join `shipment` `s` on((`o`.`OrderID` = `s`.`OrderID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_customer_with_region`
--

/*!50001 DROP VIEW IF EXISTS `v_customer_with_region`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_customer_with_region` AS select `c`.`CustomerID` AS `CustomerID`,`c`.`CustomerName` AS `CustomerName`,`c`.`Country` AS `Country`,`r`.`RegionName` AS `Region`,`c`.`CreditLimit` AS `CreditLimit` from (`customer` `c` join `region` `r` on((`c`.`RegionID` = `r`.`RegionID`))) order by `r`.`RegionName` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-07-08 17:23:11
