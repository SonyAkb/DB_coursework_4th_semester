-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: coursework_db_akbasheva
-- ------------------------------------------------------
-- Server version	8.0.39

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `customer`
--

DROP TABLE IF EXISTS `customer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customer` (
  `CustomerID` int NOT NULL AUTO_INCREMENT,
  `CustomerName` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `Address` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `PostalCode` varchar(20) NOT NULL,
  `City` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `State` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `Country` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `Phone` varchar(20) NOT NULL,
  `Email` varchar(255) DEFAULT NULL,
  `CreditLimit` decimal(15,2) DEFAULT NULL,
  `RegionID` int NOT NULL,
  PRIMARY KEY (`CustomerID`),
  KEY `RegionID` (`RegionID`),
  KEY `idx_customer_country` (`Country`),
  CONSTRAINT `customer_ibfk_1` FOREIGN KEY (`RegionID`) REFERENCES `region` (`RegionID`),
  CONSTRAINT `chk_credit_limit` CHECK ((`CreditLimit` >= 0)),
  CONSTRAINT `chk_email` CHECK (((`Email` like _utf8mb4'%@%.%') or (`Email` is null)))
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer`
--

LOCK TABLES `customer` WRITE;
/*!40000 ALTER TABLE `customer` DISABLE KEYS */;
INSERT INTO `customer` VALUES (1,'Big John\'s Sports Emporium','300 Jefferson St','94133','San Francisco','CA','USA','+14155551234','sales@bigjohns.com',50000.00,1),(2,'Womansport','1501 4th Ave','98101','Seattle','WA','USA','+12065559876','orders@womansport.com',45000.00,1),(3,'Extreme Gear','5505 Peachtree Rd','30341','Atlanta','GA','USA','+14045554321','info@extremegear.com',30000.00,1),(4,'Mountain Kings','1600 Maple St','80302','Boulder','CO','USA','+13035556789','sales@mtkings.com',35000.00,1),(5,'Fitness Pro','2000 Fitness Way','M5V 3L5','Toronto','ON','Canada','+14165550000','contact@fitnesspro.ca',40000.00,1),(6,'Sporty Kids','123 Playground Ave','H3B 2Y5','Montreal','QC','Canada','+15145551111','hello@sportykids.ca',25000.00,1),(7,'EuroFit','Friedrichstrasse 68','10117','Berlin',NULL,'Germany','+49305556677','order@eurofit.de',38000.00,6),(8,'Alpine Sports','Rue du Mont-Blanc 15','1201','Geneva',NULL,'Switzerland','+41225554433','sales@alpine.ch',42000.00,6),(9,'London Athletics','Oxford Street 250','W1C 1DJ','London',NULL,'UK','+442077788899','info@londonathletics.co.uk',35000.00,6),(10,'Tokyo Active','1-2-3 Shibuya','150-0043','Tokyo',NULL,'Japan','+81354567890','support@tokyoactive.jp',48000.00,5),(11,'Shanghai Sports','Nanjing Road 123','200001','Shanghai',NULL,'China','+862158963214','enquiry@shanghaisports.cn',52000.00,5),(12,'Seoul Fitness','Gangnam-daero 132','06164','Seoul',NULL,'South Korea','+82237895678','sales@seoulfitness.kr',40000.00,5),(13,'Rio Active','Copacabana Beach 200','22070-010','Rio de Janeiro','RJ','Brazil','+552155512345','contact@rioactive.com.br',28000.00,2),(14,'Dubai Sports','Sheikh Zayed Rd 1000','00000','Dubai',NULL,'UAE','+97145556677','orders@dubaisports.ae',60000.00,4),(15,'Cape Town Outdoors','Table Mountain Rd','8001','Cape Town',NULL,'South Africa','+27215558899','info@capetownoutdoors.co.za',32000.00,3);
/*!40000 ALTER TABLE `customer` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-07-08 17:23:07
